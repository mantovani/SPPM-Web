use strict;
use LibPDF;
use PDF::Haru;
use Data::Dumper;
print "pdf start..\n";
my $pdf = new LibPDF;
#print "30/mm in pt = " . (30/mm) . "\n";


my $image = new PDFImage({
	pdf  => $pdf,
	file => 'teste_dpi.png'
});
my $font_r = $pdf->haru->GetFont("Helvetica", "WinAnsiEncoding");
my $font_b = $pdf->haru->GetFont("Helvetica-Bold", "WinAnsiEncoding");
my $font_i = $pdf->haru->GetFont("Helvetica-Oblique", "WinAnsiEncoding");
print "100 pages\n";

for (1..1){
	my $page = $pdf->haru->AddPage();
	$page->SetSize(HPDF_PAGE_SIZE_LETTER, HPDF_PAGE_PORTRAIT);
	my $font_w = 0;
	#$page->SetWidth(200/mm);
	#$page->SetHeight(600/mm);

=pod
	$image->add2page({
		page  => $page,
		dpi   => 300,
		transform => {
			translate => [0, 200/mm]
		}
	});
=cut


	for my $a ('left', 'center', 'right'){
		for (0,10,20,30,40,50,60){
			new PDFSimpleText()->plot({
				page => $page,
				text => "$_ The quick brown fox jumps over the lazy dogXXXXXXXXXXXXXXXXXXXXXXXXXxx.",
				font => $font_w++ % 2 ? $font_r : $font_b,
				size => 8 + ($_/10), # /
				transform => {
					translate => [10/mm, ($a eq 'left'? 0 : $a eq 'center' ? 180 : $a eq 'right' ? 300 : 350) + $_/mm ] # /
				},
				charspacing => 1.5,
				wordspacing => 2.5,
				align => $a,
				limit_width => 100/mm
			});
		}
	}


	new PDFTagedText()->plot({
		page => $page,
		text => "<b>Prezado Cliente:</b> EVANDRO S SANTOS WASSABT OHWAWS SANTOS WASSABT",
		fonts => {
			default => $font_r,
			b       => $font_b
		},
		size => 10,
		transform => {
			translate => [ 40/mm, 40/mm ]
		},
		charspacing => 0,
		wordspacing => 0,
		align       => 'left',
		limit_width => 80/mm
	});

	new PDFTagedText()->plot({
		page => $page,
		text => "<b>Prezado Cliente:</b> EVANDRO S SANTOS WASSABT OHWAWS SANTOS WASSABT",
		fonts => {
			default => $font_r,
			b       => $font_b
		},
		size => 10,
		transform => {
			translate => [ 40/mm, 50/mm ]
		},
		charspacing => 0,
		wordspacing => 0,
		align       => 'left',
		#limit_width => 60/mm
	});

	new PDFTagedText()->plot({
		page => $page,
		text => "<b>Prezado Cliente:</b> EVANDRO S SANTOS WASSABT OHWAWS SANTOS WASSABT",
		fonts => {
			default => {font=>$font_r},
			b       => {font=>$font_b}
		},
		size => 10,
		transform => {
			translate => [ 40/mm, 60/mm ]
		},
		charspacing => 0,
		wordspacing => 0,
		align       => 'left',
		limit_width => 60/mm
	});
	new PDFBarcode()->plot({
		page => $page,
		type => 'DataMatrix',
		transform => {
			translate => [100/mm, 100/mm ]
		},
		options => [
			-ean  => 0 ,
			-font => $font_r, # the font to use for text
			-type => 'c', # the type of barcode
			-code => "03640000", # the code of the barcode
			-extn => undef, # the extension of the barcode
			-umzn => 30, # (u)pper (m)ending (z)o(n)e
			-lmzn => 0, # (l)ower (m)ending (z)o(n)e
			-zone => 30, # height (zone) of bars
			-quzn => 0 , # (qu)iet (z)o(n)e
			-ofwt => .1, # (o)ver(f)low (w)id(t)h
			-font_size => 9, # (f)o(n)t(s)i(z)e
			-text => undef,
			point_size=>3
		]

	});
	my $VAR1 = {
          #"lead" => 10,
          "align" => "justify",
          "transform" => {
                           "rotate" => undef,
                           "translate" => [
                                            "64.519685039",
                                            "467.884251969"
                                          ],
                           "scale" => undef,
                           "not_relative" => 1
                         },
          "page" => $page,
          "wordspacing" => 0,
          "indent" => 0,
          "fonts" => {
                       "b" => {
                                "font" => $font_b,
                                "size" => 30,"decrease_size" =>.02
                              },
                       "default" => {
                                      "font" => $font_r,
                                      "size" => 30,
											"decrease_size" => .02
                                    }
                     },
          "fpindent" => undef,
          "max_height" => 100/mm,
          "text" => "Nullam id enim a sem hendrerit tristique. Cum <b>sociis natoque penatibus et</b> magnis dis parturient montes, nascetur ridiculus mus. Sed sodales purus <b>eget dolor scelerisque quis accumsan tortor imperdiet. Quisque porttitor ipsum non sapien iaculis tristique.</b> Sed nec leo ligula, sit amet aliquet nibh. Suspendisse quis ante leo. Phasellus nibh turpis, sollicitudin ullamcorper tristique mattis, suscipit vitae ligula. Maecenas <b>vulputate</b> erat sit amet ante dictum malesuada. Proin ultrices mollis nisl sed pharetra. Mauris diam dolor, tristique eget laoreet vel, aliquam eget mauris. Integer malesuada, nisl molestie hendrerit gravida, dui leo porta lorem, ut sodales massa turpis a tortor. Morbi vitae tellus eros. In in massa erat, non iaculis justo. Donec ultricies elit quis odio ultrices gravida. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Nullam et ligula at lectus consequat malesuada ut vel nisi. Integer vel iaculis dolor. Phasellus accumsan magna dui. Suspendisse tempor elementum dui, quis ultricies nulla facilisis at. Aenean cursus varius odio eu bibendum.",
          "flindent" => 0,
          "max_width" => 100/mm,
          "charspacing" => 0,
          "parspace" => undef,
			debug_rect => 1,
			all_text => 1,
			decrease_lead=>.02

        };

	my $VAR1 = {"lead" => 10,
          "page" => $page,
          "fonts" => {
                       "default" => {
                                      "font" => $font_r,
                                      "decrease_size" => "0.1",
                                      "size" => 9
                                    }
                     },
          "text" => "( ) 01 parcela(s) de R\$ 1.669,33 (Parcela \332nica) ( ) 03 parcela(s) de R\$ 932,70 ( ) 12 parcela(s) de R\$ 234,50 ( ) 24 parcela(s) de R\$ 117,71 ( ) 36 parcela(s) de R\$ 78,57  *Constam somente as d\355vidas de Cart\343o de Cr\351dito com forma de pagamento por meio de d\351bito em conta corrente, vencidas at\351 20/07/2009",
          "charspacing" => 0,
          "pos_relative_to_center" => undef,
          "all_text" => 1,
          "transform" => {
                           "rotate" => undef,
                           "translate" => [
                                            55,
                                            "501.435433070866"
                                          ],
                           "scale" => undef,
                           "not_relative" => 1
                         },
          "align" => "justify",
          "wordspacing" => 0,
          "indent" => 0,
          "fpindent" => undef,
          "decrease_lead" => "0.1",
          "flindent" => undef,
          "max_height" => "566.929133858268",
          "max_width" => "481.889763779528",
          "parspace" => 5,
          "debug_rect" => 0};

	my ($endx, $endy, @resto) = new PDFRectText()->plot($VAR1);



	new PDFRectText()->plot({
		page => $page,
		text => "The quick brown fox jumps over the <b>lazy dog. </b>more text on this line\n\nSecond pharagraphy ".
		"with a lot of random words <b>on</b>with a lot of random words <big>on</big>with a lot of random words <b>on</b>with a lot of random words <b>on</b>with a lot of random words <b>on</b>with a lot of random words <b>on</b>with a lot of random words <b>on</b> here!\nNext line!<big>BIG</big>.\n\nThis is a new pharagraphy, but short.\n\n\n\n\nLot of pharagraphy after!",
		font => $font_r,
		size => 15,
		lead => 10+$xxx,
		parspace => 1/mm,

		fonts => {
			default => {
				font => $font_r,
				size => 8+$xxx
			},
			b => {
				font => $font_b,
				size => 8+$xxx
			},
			big => {
				font => $font_i,
				size => 13+$xxx
			}
		},
		transform => {
			translate => [40/mm, 40/mm],
		},
		charspacing => 1.5,
		wordspacing => 2.5,
		align => 'center',
		max_width => 40/mm,
		max_height => 400/mm,
	});

	new PDFRectText()->plot({
		page => $page,
		text => "The quick brown fox jumps over the <b>lazy dog. </b>more text on this line\n\nSecond pharagraphy ".
		"with a lot of random words <b>on</b>with a lot of random words <big>on</big>with a lot of random words <b>on</b>with a lot of random words <b>on</b>with a lot of random words <b>on</b>with a lot of random words <b>on</b>with a lot of random words <b>on</b> here!\nNext line!<big>BIG</big>.\n\nThis is a new pharagraphy, but short.\n\n\n\n\nLot of pharagraphy after!",
		font => $font_r,
		size => 15,
		lead => 10+$xxx,
		parspace => 1/mm,

		fonts => {
			default => {
				font => $font_r,
				size => 8+$xxx
			},
			b => {
				font => $font_b,
				size => 8+$xxx
			},
			big => {
				font => $font_i,
				size => 13+$xxx
			}
		},
		transform => {
			translate => [90/mm, 40/mm],
		},
		charspacing => 1.5,
		wordspacing => 2.5,
		align => 'left',
		max_width => 50/mm,
		max_height => 400/mm,
	});


	new PDFRectText()->plot({
		page => $page,
		text => "The quick brown fox jumps over the <b>lazy dog. </b>more text on this line\n\nSecond pharagraphy ".
		"with a lot of random words <b>on</b>with a lot of random words <big>on</big>with a lot of random words <b>on</b>with a lot of random words <b>on</b>with a lot of random words <b>on</b>with a lot of random words <b>on</b>with a lot of random words <b>on</b> here!\nNext line!<big>BIG</big>.\n\nThis is a new pharagraphy, but short.\n\n\n\n\nLot of pharagraphy after!",
		font => $font_r,
		size => 15,
		lead => 10+$xxx,
		parspace => 1/mm,

		fonts => {
			default => {
				font => $font_r,
				size => 8+$xxx
			},
			b => {
				font => $font_b,
				size => 8+$xxx
			},
			big => {
				font => $font_i,
				size => 13+$xxx
			}
		},
		transform => {
			translate => [130/mm, 40/mm],
		},
		charspacing => 1.5,
		wordspacing => 2.5,
		align => 'right',
		max_width => 50/mm,
		max_height => 400/mm,
	});

	new PDFRectText()->plot({
		page => $page,
		text => "The quick brown fox jumps over the <b>lazy dog. </b>more text on this line\n\nSecond pharagraphy ".
		"with a lot of random words <b>on</b>with a lot of random words <big>on</big>with a lot of random words <b>on</b>with a lot of random words <b>on</b>with a lot of random words <b>on</b>with a lot of random words <b>on</b>with a lot of random words <b>on</b> here!\nNext line!<big>BIG</big>.\n\nThis is a new pharagraphy, but short.\n\n\n\n\nLot of pharagraphy after!",
		font => $font_r,
		size => 15,
		lead => 10+$xxx,
		parspace => 1/mm,

		fonts => {
			default => {
				font => $font_r,
				size => 8+$xxx
			},
			b => {
				font => $font_b,
				size => 8+$xxx
			},
			big => {
				font => $font_i,
				size => 13+$xxx
			}
		},
		transform => {
			translate => [170/mm, 40/mm],
		},
		charspacing => 1.5,
		wordspacing => 2.5,
		align => 'fulljustify',
		max_width => 50/mm,
		max_height => 400/mm,
	});



	new PDFBarcode()->plot({
		page => $page,
		type => 'code128',
		transform => {
			translate => [100/mm, 50/mm ]
		},
		options => [
			-ean  => 0 ,
			-font => $font_r, # the font to use for text
			-type => 'a', # the type of barcode
			-code => "0000ML000004815", # the code of the barcode
			-extn => undef, # the extension of the barcode
			-umzn => 30, # (u)pper (m)ending (z)o(n)e
			-lmzn => 0, # (l)ower (m)ending (z)o(n)e
			-zone => 30, # height (zone) of bars
			-quzn => 0 , # (qu)iet (z)o(n)e
			-ofwt => .1, # (o)ver(f)low (w)id(t)h
			-font_size => 9, # (f)o(n)t(s)i(z)e
			-text => undef
		]
	});

	new PDFBarcode()->plot({
		page => $page,
		type => 'code128',
		transform => {
			translate => [10/mm, 50/mm ]
		},
		options => [
			-ean  => 0 ,
			-font => $font_r, # the font to use for text
			-type => 'a', # the type of barcode
			-code => "000055000004815", # the code of the barcode
			-extn => undef, # the extension of the barcode
			-umzn => 30, # (u)pper (m)ending (z)o(n)e
			-lmzn => 0, # (l)ower (m)ending (z)o(n)e
			-zone => 30, # height (zone) of bars
			-quzn => 0 , # (qu)iet (z)o(n)e
			-ofwt => .1, # (o)ver(f)low (w)id(t)h
			-font_size => 9, # (f)o(n)t(s)i(z)e
			-text => undef,
			point_size=>3
		]
	});

	new PDFBarcode()->plot({
		page => $page,
		type => 'code128',
		transform => {
			translate => [10/mm, 100/mm ]
		},
		options => [
			-ean  => 0 ,
			-font => $font_r, # the font to use for text
			-type => 'a', # the type of barcode
			-code => "RENATOSANTOS", # the code of the barcode
			-extn => undef, # the extension of the barcode
			-umzn => 30, # (u)pper (m)ending (z)o(n)e
			-lmzn => 0, # (l)ower (m)ending (z)o(n)e
			-zone => 30, # height (zone) of bars
			-quzn => 0 , # (qu)iet (z)o(n)e
			-ofwt => .1, # (o)ver(f)low (w)id(t)h
			-font_size => 9, # (f)o(n)t(s)i(z)e
			-text => undef,
			point_size=>3
		]
	});

	new PDFBarcode()->plot({
		page => $page,
		type => 'code128',
		transform => {
			translate => [10/mm, 150/mm ]
		},
		options => [
			-ean  => 0 ,
			-font => $font_r, # the font to use for text
			-type => 'a', # the type of barcode
			-code => "987654000000008182", # the code of the barcode
			-extn => undef, # the extension of the barcode
			-umzn => 30, # (u)pper (m)ending (z)o(n)e
			-lmzn => 0, # (l)ower (m)ending (z)o(n)e
			-zone => 30, # height (zone) of bars
			-quzn => 0 , # (qu)iet (z)o(n)e
			-ofwt => .1, # (o)ver(f)low (w)id(t)h
			-font_size => 9, # (f)o(n)t(s)i(z)e
			-text => undef,
			point_size=>3
		]
	});

	new PDFBarcode()->plot({
		page => $page,
		type => 'code128',
		transform => {
			translate => [10/mm, 200/mm ]
		},
		options => [
			-ean  => 0 ,
			-font => $font_r, # the font to use for text
			-type => 'a', # the type of barcode
			-code => "00000000000000008182", # the code of the barcode
			-extn => undef, # the extension of the barcode
			-umzn => 30, # (u)pper (m)ending (z)o(n)e
			-lmzn => 0, # (l)ower (m)ending (z)o(n)e
			-zone => 30, # height (zone) of bars
			-quzn => 0 , # (qu)iet (z)o(n)e
			-ofwt => .1, # (o)ver(f)low (w)id(t)h
			-font_size => 9, # (f)o(n)t(s)i(z)e
			-text => undef,
			point_size=>3
		]
	});
}
print "saving...\n";
$pdf->haru->SaveToFile("filename.pdf");
print "done!\n";

print "PDF_SIZE = ".(-s "filename.pdf")." bytes \n";

undef($pdf);


