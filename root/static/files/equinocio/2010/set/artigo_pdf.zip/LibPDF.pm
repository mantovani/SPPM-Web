use strict;
use constant mm => 25.4 / 72;
use constant in => 1 / 72;
use constant pt => 1;

use Exporter;
our @EXPORT = qw (mm in pt );

#=======================================================================================================================
#
#=======================================================================================================================
package PDFObject;
use strict;
use PDF::Haru;
use LibPDF::Matrix;
use Math::Trig;

sub new {
	my $this = shift;
	my $class = ref($this) || $this;
	my $self = {};
	bless $self, $class;
	return $self;
}

sub initialize {

}

=item $co->translate $x,$y

Sets translation transformation.

=cut

sub _translate
{
    my ($x,$y)=@_;
    return(1,0,0,1,$x,$y);
}

sub translate
{
  my ($self,$page, $x,$y)=@_;
  $self->transform(translate=>[$x,$y], page =>$page);
}

=item $co->scale $sx,$sy

Sets scaleing transformation.

=cut

sub _scale
{
    my ($x,$y)=@_;
    return($x,0,0,$y,0,0);
}
sub scale
{
	my ($self,$page,$sx,$sy)=@_;
	$sy ||= $sx;
	$self->transform(scale=>[$sx,$sy], page=>$page);
}

=item $co->skew $sa,$sb

Sets skew transformation.

=cut

sub _skew
{
    my ($a,$b)=@_;
    return(1, tan(deg2rad($a)),tan(deg2rad($b)),1,0,0);
}
sub skew
{
  my ($self,$page,$a,$b)=@_;
  $self->transform(skew=>[$a,$b],page=>$page);
}

=item $co->rotate $rot

Sets rotation transformation.

=cut

sub _rotate
{
    my ($a)=@_;
    return(cos(deg2rad($a)), sin(deg2rad($a)),- sin(deg2rad($a)), cos(deg2rad($a)),0,0);
}
sub rotate
{
  my ($self,$page, $a)=@_;
  $self->transform(rotate=>$a,page=>$page);
}

=item $co->transform %opts

Sets transformations (eg. translate, rotate, scale, skew) in pdf-canonical order.

B<Example:>

    $co->transform(
        -translate => [$x,$y],
        -rotate    => $rot,
        -scale     => [$sx,$sy],
        -skew      => [$sa,$sb],
    )

=cut

sub _transform
{
    my (%opt)=@_;
    my $mtx=LibPDF::Matrix->new([1,0,0],[0,1,0],[0,0,1]);
    foreach my $o (qw( matrix skew scale rotate translate )) {
        next unless(defined($opt{$o}));
        if($o eq 'translate') {
			unless ($opt{not_relative}){
				$opt{$o}[1] = $opt{page}->GetHeight() - $opt{$o}[1];
			}
            my @mx=_translate(@{$opt{$o}});
            $mtx=$mtx->multiply(LibPDF::Matrix->new(
                [$mx[0],$mx[1],0],
                [$mx[2],$mx[3],0],
                [$mx[4],$mx[5],1]
            ));
        } elsif($o eq 'rotate') {
            my @mx=_rotate($opt{$o});
            $mtx=$mtx->multiply(LibPDF::Matrix->new(
                [$mx[0],$mx[1],0],
                [$mx[2],$mx[3],0],
                [$mx[4],$mx[5],1]
            ));
        } elsif($o eq 'scale') {
			$opt{$o} = [$opt{$o},$opt{$o}] if (ref $opt{$o} ne 'ARRAY');
            my @mx=_scale(@{$opt{$o}});
            $mtx=$mtx->multiply(LibPDF::Matrix->new(
                [$mx[0],$mx[1],0],
                [$mx[2],$mx[3],0],
                [$mx[4],$mx[5],1]
            ));
        } elsif($o eq 'skew') {
            my @mx=_skew(@{$opt{$o}});
            $mtx=$mtx->multiply(LibPDF::Matrix->new(
                [$mx[0],$mx[1],0],
                [$mx[2],$mx[3],0],
                [$mx[4],$mx[5],1]
            ));
        } elsif($o eq 'matrix') {
            my @mx=@{$opt{$o}};
            $mtx=$mtx->multiply(LibPDF::Matrix->new(
                [$mx[0],$mx[1],0],
                [$mx[2],$mx[3],0],
                [$mx[4],$mx[5],1]
            ));
        }
    }
    if($opt{point})
    {
        my $mp=LibPDF::Matrix->new([$opt{point}->[0],$opt{point}->[1],1]);
        $mp=$mp->multiply($mtx);
        return($mp->[0][0],$mp->[0][1]);
    }
    return(
		$opt{page},
        $mtx->[0][0],$mtx->[0][1],
        $mtx->[1][0],$mtx->[1][1],
        $mtx->[2][0],$mtx->[2][1]
    );
}

sub transform {
    my ($self,%opt)=@_;

    $self->matrix(_transform(%opt));

    return($self);
}

sub matrix
{
    my $self=shift @_;
    my ($page, $a,$b,$c,$d,$e,$f)=@_;
    if(defined $a)
    {
		$page->Concat($a,$b,$c,$d,$e,$f);
    }
}

#=======================================================================================================================
#
#=======================================================================================================================
package PDFSimpleText;
use strict;
use PDF::Haru;
use base 'PDFObject';
use Data::Dumper;

sub plot {
	my ($this, $param) = @_;

	my $page = $param->{page};

	$page->GSave();

	$page->SetWordSpace($param->{wordspacing}) if (defined $param->{wordspacing});
	$page->SetCharSpace($param->{charspacing}) if (defined $param->{charspacing});

	my $size = $param->{size}||8;
	$page->SetFontAndSize($param->{font}, $size);

	if (defined $param->{limit_width}){
		while ($page->TextWidth($param->{text}) > $param->{limit_width} && $size >= 5){
			$size -=.5;
			$page->SetFontAndSize($param->{font}, $size);
		}
	}

	$param->{transform} ||= {};
	my @param = (page => $page);
	$param->{transform}{translate}[1] += $param->{size}; # y

	if ($param->{align} eq 'right' || $param->{align} eq 'center'){
		my $text_width = $page->TextWidth($param->{text});

		$text_width /= 2 if ($param->{align} eq 'center');

		$param->{transform}{translate}[0] -= $text_width;
	}

	push(@param, $_, $param->{transform}{$_}) foreach (keys %{$param->{transform}});
	$this->transform(@param);



	$page->BeginText();
	$page->ShowText($param->{text});
	$page->EndText();

	$page->GRestore();
}


#=======================================================================================================================
# Taged Text:
# ALERT tag font size down with the same size
#=======================================================================================================================
package PDFTagedText;
use strict;
use PDF::Haru;
use base 'PDFObject';
use Data::Dumper;

sub plot {
	my ($this, $param) = @_;

	my $page = $param->{page};

	$page->GSave();

	$page->SetWordSpace($param->{wordspacing}) if (defined $param->{wordspacing});
	$page->SetCharSpace($param->{charspacing}) if (defined $param->{charspacing});

	my $size = $param->{size}||8;

	$page->SetFontAndSize($param->{fonts}{default}{font}, $size);

	my @words = split( /\s+/, $param->{text} );
    my %width = ();
    foreach my $word(@words) {
        next if exists $width{$word};

		my $tag;
		if (($tag) = ($word =~ /<(.*?)>/)) {
			if ($tag !~ /^\//){
				unless ($param->{fonts}{$tag}) {
					$page->SetFontAndSize($param->{fonts}{default}{font}, $size);
				}
				else{
					$page->SetFontAndSize($param->{fonts}{$tag}{font}, $size);
				}
			}
		}

		my $stripped = $word;
		$stripped =~ s/<.*?>//g;
		$width{$word} = $page->TextWidth($stripped);

		# se a palavra ja abriu e fechou a tag
		if ($tag && $tag =~ /^\//) {
			$page->SetFontAndSize($param->{fonts}{default}{font}, $size);
		}

	}
	my $line_width = $this->getWidth({
		width => \%width,
		words => \@words
	});
	if (defined $param->{limit_width}){
		if ($line_width > $param->{limit_width} && $size >= 5){
			$size -= .5;

			$param->{size} = $size;

			# ALERT matenha isso
			return $this->plot($param);

		}
	}

	$page->SetFontAndSize($param->{fonts}{default}{font}, $size);

	$param->{transform} ||= {};
	my @param = (page => $page);
	$param->{transform}{translate}[1] += $param->{size}; # y

	if ($param->{align} eq 'right' || $param->{align} eq 'center'){
		my $text_width = $page->TextWidth($param->{text});

		$text_width /= 2 if ($param->{align} eq 'center');

		$param->{transform}{translate}[0] -= $text_width;
	}

	push(@param, $_, $param->{transform}{$_}) foreach (keys %{$param->{transform}});
	$this->transform(@param);

	my $xpos = 0;

	my $align = $param->{align};

	if ( $align eq 'right') {
		$xpos += $line_width;
	}
	elsif ( $align eq 'center' ) {
		$xpos += $line_width / 2;
	}
	my $wordspace = $page->TextWidth(' ');

	foreach my $word (@words) {
		my $tag;
		if (($tag) = ($word =~ /<(.*?)>/)){
			if ($tag !~ /\//) {
				$page->SetFontAndSize($param->{fonts}{$tag}{font}, $size);
			}
		}

		my $stripped = $word;
		$stripped =~ s/<.*?>//g;

		$page->BeginText();
		$page->MoveTextPos( $xpos, 0 );
		$page->ShowText($stripped);
		$page->EndText();

		$xpos += ( $width{$word} + $wordspace );

		if ($word =~ /\//) {
			$page->SetFontAndSize($param->{fonts}{default}{font}, $size);
		}

	}

	$page->GRestore();
	return {
		font_size => $size
	}
}

sub getWidth {
	my $this  = shift;
	my $param = shift;


	my %width = %{$param->{width}};
	my @words = @{$param->{words}};

	my $size = 0;

	foreach (@words){
		$size += $width{$_};
	}

	return $size;
}

#=======================================================================================================================
#
#=======================================================================================================================
package PDFRectText;
use strict;
use PDF::Haru;
use base 'PDFObject';
use Data::Dumper;
use warnings;

sub plot {
	my ($this, $param) = @_;

	my $page = $param->{page};

	$page->GSave();

	$page->SetWordSpace($param->{wordspacing}) if (defined $param->{wordspacing});
	$page->SetCharSpace($param->{charspacing}) if (defined $param->{charspacing});

	$param->{transform} ||= {};
	my @param = (page => $page);

	if ($param->{pos_relative_to_center}){
		# volta meio box
		$param->{transform}{translate}[0]  -= $param->{max_width} / 2;
		$param->{transform}{translate}[1] ||= 0;
	}

	push(@param, $_, $param->{transform}{$_}) foreach (keys %{$param->{transform}});
	$this->transform(@param);

	$param->{lead} ||= $param->{fonts}{default}{size};
	if ($param->{debug_rect}){
		my $ret = $page->GetGrayFill();
		$page->SetGrayFill(0.5);
		$page->Rectangle(0, 0, $param->{max_width}, -$param->{max_height});
		$page->Fill();
		$page->SetGrayFill($ret);

		$ret = $page->GetGrayStroke();
		$page->SetGrayStroke(0);
		$page->Rectangle(0, 0, $param->{max_width}, -$param->{max_height});
		$page->Stroke();
		$page->SetGrayStroke($ret);
	}

	$this->text_block(
		page     => $page,

		fonts    => $param->{fonts},
		text     => $param->{text},
		w        => $param->{max_width},
		h        => $param->{max_height},
		lead     => $param->{lead},
		parspace => $param->{parspace}||0,
		align    => $param->{align},
		hang     => $param->{hang},
		flindent => $param->{flindent},
		indent   => $param->{indent},
		fpindent => $param->{fpindent},
		nochange => $param->{nochange},

		all_text      => $param->{all_text},
		decrease_lead => $param->{decrease_lead}||0.5
	);
	$page->GRestore();

}

sub text_block {
	my $this = shift();

    my %arg = @_;
	my $text = $arg{text};
	my $font = $arg{font};
	my $page = $arg{page};

	unless ($arg{nochange}){
		# tags mal abertas: "Next line!<big>" => "Next line! <big>"
		$text =~ s/([^\s])<([^\/])/$1 <$2/g;

		# tags mal fechadas: "closing</big>new word" => "closing</big> new word"
		$text =~ s/(<\/([^>]+)>)([^\s])/$1 $3/g;

		# tira os tabs, que "bugam" o alinhamento
		$text =~ s/\t+/ /g;
	}

	$page->SetFontAndSize($arg{fonts}{default}{font}, $arg{fonts}{default}{size});

	# calculate width of all words
	my @words = split( /\s+/, $text );
    my %width = ();
    foreach my $word(@words) {
        next if exists $width{$word};

		my $tag;
		if (($tag) = ($word =~ /<(.*?)>/)) {
			if ($tag !~ /^\//){
				unless ($arg{fonts}{$tag}) {
					$page->SetFontAndSize($arg{fonts}{default}{font}, $arg{fonts}{default}{size});
				}
				else{
					$page->SetFontAndSize($arg{fonts}{$tag}{font}, $arg{fonts}{$tag}{size});
				}
			}
		}

		my $stripped = $word;
		$stripped =~ s/<.*?>//g;

		# BUG 1: palavras iguais com fontes (muito) diferentes
		$width{$word} = $page->TextWidth($stripped);

		# TODO solve this problem...
		if ($width{$word} > $arg{'w'}){
			warn("Too large word '$word' ($width{$word}) for max_width ($arg{'w'})");
		}
		# se a palavra ja abriu e fechou a tag
		if ($tag && $tag =~ /^\//) {
			$page->SetFontAndSize($arg{fonts}{default}{font}, $arg{fonts}{default}{size});
		}

	}
	$page->SetFontAndSize($arg{fonts}{default}{font}, $arg{fonts}{default}{size});
	$arg{'y'} = 0;
	$arg{'x'} = 0;

	my $space_width = $page->TextWidth(' ');

	 # Get the text in paragraphs
    my @paragraphs = split( /\n/, $text );

	my ($endw, $ypos);
	unless ($arg{all_text}) {
		($endw, $ypos, @paragraphs) = $this->text_block_paragraph({
			print_text  => 1,
			arg         => \%arg,
			width       => \%width,
			paragraphs  => \@paragraphs,
			space_width => $space_width,
			page        => $page
		});
	}else{

		($endw, $ypos, @paragraphs) = $this->text_block_paragraph({
			print_text  => 0,
			arg         => \%arg,
			width       => \%width,
			paragraphs  => \@paragraphs,
			space_width => $space_width,
			page        => $page
		});


		if (scalar join('',@paragraphs) ne '' && $arg{fonts}{default}{size} > 1){
			$arg{'y'} = 0;
			$arg{'x'} = 0;

			# reloading...
			@paragraphs = split( /\n/, $text );

			# diminue a fonte
			foreach (keys %{$arg{fonts}}){
				$arg{fonts}{$_}{size} -= $arg{fonts}{$_}{decrease_size}||0.5;

				$arg{fonts}{$_}{size} = $arg{fonts}{$_}{size} < 1 ? 1 : $arg{fonts}{$_}{size};
			}
			$arg{lead} -= $arg{decrease_lead};
			@_ = %arg;

			return $this->text_block(@_);

		}else{
			$arg{'y'} = 0;
			$arg{'x'} = 0;
			# reloading...
			@paragraphs = split( /\n/, $text );

			($endw, $ypos, @paragraphs) = $this->text_block_paragraph({
				print_text  => 1,
				arg         => \%arg,
				width       => \%width,
				paragraphs  => \@paragraphs,
				space_width => $space_width,
				page        => $page
			});

		}

	}

    return ( $endw, $ypos, join( "\n", @paragraphs ) );
}


sub text_block_paragraph {
	my ($this, $param) = @_;

	my $space_width = $param->{space_width};
	my $page        = $param->{page};

	my %arg        = %{$param->{arg}};
	my %width      = %{$param->{width}};

	my @paragraphs = @{$param->{paragraphs}};

	my $ypos = $arg{'y'} - $arg{'lead'};
    my @paragraph = split( / /, shift(@paragraphs) ); # VI SYNTAX HACK /

    my $first_line      = 1;
    my $first_paragraph = 1;
	my $endw            = 0;

    # while we can add another line

	while ( $ypos >= $arg{'y'} - $arg{'h'} + $arg{'lead'} ) {

		unless (@paragraph) {

			last unless scalar @paragraphs;

			@paragraph = split( / /, shift(@paragraphs) ); # /

			$ypos -= $arg{'parspace'} if $arg{'parspace'};

			unless ($arg{all_text}) {
				last unless $ypos >= $arg{'y'} - $arg{'h'};
			}

			$first_line      = 1;
			$first_paragraph = 0;
		}

		my $xpos = $arg{'x'};

		# while there's room on the line, add another word
		my @line = ();

		my $line_width = 0;
		if ( $first_line && defined $arg{'hang'} ) {

			my $hang_width = $page->TextWidth( $arg{'hang'} );

			if($param->{print_text}){
				$page->BeginText();
				$page->MoveTextPos( $xpos, $ypos );
				$page->ShowText( $arg{'hang'} );
				$page->EndText();
			}
			$xpos       += $hang_width;
			$line_width += $hang_width;
			$arg{'indent'} += $hang_width if $first_paragraph;

		}
		if ( $first_line && defined $arg{'flindent'} ) {

			$xpos       += $arg{'flindent'};
			$line_width += $arg{'flindent'};

		}
		elsif ( $first_paragraph && defined $arg{'fpindent'} ) {

			$xpos       += $arg{'fpindent'};
			$line_width += $arg{'fpindent'};

		}
		elsif ( defined $arg{'indent'} ) {

			$xpos       += $arg{'indent'};
			$line_width += $arg{'indent'};

		}

		while ( @paragraph
			and $line_width + (( scalar(@line) * $space_width||0 )||0) +
			($width{ $paragraph[0]||'' }||0) < $arg{'w'} )
		{
			$line_width += $width{ $paragraph[0] || ''} || 0;

			push( @line, shift(@paragraph)||'' ) if (@paragraph);

		}

		# calculate the space width
		my ( $wordspace, $align );
		if ( $arg{'align'} eq 'fulljustify'
			or ( $arg{'align'} eq 'justify' and @paragraph ) )
		{

			if ( scalar(@line) == 1 ) {
				@line = split( //, $line[0] );
			}

			if ( scalar(@line) - 1 ){

				$wordspace = ( $arg{'w'} - $line_width ) / ( scalar(@line) - 1 );

			}else{
				$wordspace = 0;
			}

			$align = 'justify';
		}
		else {
			$align = ( $arg{'align'} eq 'justify' ) ? 'left' : $arg{'align'};

			$wordspace = $space_width;
		}
		$line_width += $wordspace * ( scalar(@line) - 1 );


		if ( $align eq 'justify' ) {

			foreach my $word (@line) {
				my $tag;
				if (($tag) = ($word =~ /<(.*?)>/)){
					if ($tag !~ /\//) {
						$page->SetFontAndSize($arg{fonts}{$tag}{font}, $arg{fonts}{$tag}{size});
					}
				}

				my $stripped = $word;
				$stripped =~ s/<.*?>//g;

				if($param->{print_text}){
					$page->BeginText();
					$page->MoveTextPos( $xpos, $ypos );
					$page->ShowText($stripped);
					$page->EndText();
				}

				# HACK
				# just added after change DIE to warning
				$width{$word} = $page->TextWidth($word) unless $width{$word};

				$xpos += ( $width{$word} +
						$wordspace ) if (@line);

				if ($word =~ /\//) {
					$page->SetFontAndSize($arg{fonts}{default}{font}, $arg{fonts}{default}{size});
				}

			}
			$endw = $arg{'w'};
		}
		else {

			if ( $align eq 'right') {
				$xpos += $arg{'w'} - $line_width;
			}
			elsif ( $align eq 'center' ) {
				$xpos += ( $arg{'w'} / 2 ) - ( $line_width / 2 );
			}

			foreach my $word (@line) {
				my $tag;
				if (($tag) = ($word =~ /<(.*?)>/)){
					if ($tag !~ /\//) {
						$page->SetFontAndSize($arg{fonts}{$tag}{font}, $arg{fonts}{$tag}{size});
					}
				}

				my $stripped = $word;
				$stripped =~ s/<.*?>//g;

				if($param->{print_text}){
					$page->BeginText();
					$page->MoveTextPos( $xpos, $ypos );
					$page->ShowText($stripped);
					$page->EndText();
 				}

				$xpos += ( ($width{$word}||0) + $wordspace ) if (@line);

				if ($word =~ /\//) {
					$page->SetFontAndSize($arg{fonts}{default}{font}, $arg{fonts}{default}{size});
				}

			}

		}
		$ypos -= $arg{'lead'};
		$first_line = 0;

    }

	unshift( @paragraphs, join( ' ', @paragraph ) ) if scalar(@paragraph);

	return ( $endw, $ypos, join( "\n", @paragraphs ) );

}

#=======================================================================================================================
#
#=======================================================================================================================
package PDFBarcode;
use strict;
use PDF::Haru;
use base 'PDFObject';
use Data::Dumper;

use LibPDF::Form::BarCode::code128;
use LibPDF::Form::BarCode::code3of9;
use LibPDF::Form::BarCode::ean13;
use LibPDF::Form::BarCode::int2of5;
use LibPDF::Form::BarCode::codabar;
# codigos removidos pois são da empresa
#use LibPDF::Form::BarCode::CepNET;
#use LibPDF::Form::BarCode::DataMatrix;

sub plot {
	my ($this, $param) = @_;

	my %options = @{$param->{options}};

	my $page = $param->{page};
	my $ret = {};
	$page->GSave();

	$param->{transform} ||= {};
	my @param = (page => $page);

	push(@param, $_, $param->{transform}{$_}) foreach (keys %{$param->{transform}});
	$this->transform(@param);

	#if ($param->{type} eq 'DataMatrix'){

	#	my $datamatrix = new LibPDF::Form::BarCode::DataMatrix( $options{-code},
	#		Type => ($options{-type}||'ASCII'),
	#		page => $page
	#	);
	#	if ($datamatrix){
	#		$datamatrix->plot(x => 0, y => 0, point_size => $options{point_size});
	#	}else{
	#		die(LibPDF::Form::BarCode::DataMatrix::getErr());
	#	}

	#}elsif ($param->{type} eq 'CepNET'){
	#	my $cepnet = new LibPDF::Form::BarCode::CepNET( $param );

	#	$cepnet->addCepNet({cep => $options{-code}});
	#}else{
		my $api = undef;
		my $supported_apis = {
			code128  => 'LibPDF::Form::BarCode::code128',
			code3of9 => 'LibPDF::Form::BarCode::code3of9',
			ean13    => 'LibPDF::Form::BarCode::ean13',
			int2of5  => 'LibPDF::Form::BarCode::int2of5',
			codabar  => 'LibPDF::Form::BarCode::codabar'
		};
		die("$param->{type} nao suportado!") unless ($api = $supported_apis->{$param->{type}});

		my $obj = $api->new_api({
				page => $page
			},
			@{$param->{options}}
		);

		$ret = $obj;
	#}

	$page->GRestore();

	return $ret;
}



#=======================================================================================================================
#
#=======================================================================================================================
package PDFImage;
use strict;
use PDF::Haru;
use base 'PDFObject';
use Data::Dumper;
sub new {
	my $this = shift;
	my $param = shift;
	my $class = ref($this) || $this;
	my $self = {};
	bless $self, $class;
	$self->PDFObject::initialize($param);

	$self->initialize($param);

	return $self;
}

sub initialize {
	my ($this, $param) = @_;

	my $file_name = $param->{file};
	my $pdf       = $param->{pdf};
	die("Arquivo de imagem $file_name nao encontrado") if (!-f $file_name);
	die("Faltou passar instancia do pdf") if (ref $pdf ne 'LibPDF');

	if ($file_name =~ /\.png/io){
		$this->{image} = $pdf->haru->LoadPngImageFromFile($file_name);
	}else{
		$this->{image} = $pdf->haru->LoadJpegImageFromFile($file_name);
	}
	($this->{width}, $this->{height}) = ($this->{image}->GetWidth(),$this->{image}->GetHeight());
}

sub add2page {
	my ($this, $param) = @_;

	my $page = $param->{page};

	$page->GSave();

	$param->{transform} ||= {};
	my @param = (page => $page);

	push(@param, $_, $param->{transform}{$_}) foreach (keys %{$param->{transform}});
	$this->transform(@param);

	$param->{page}->Concat(72.0 / $param->{dpi}, 0, 0, 72.0 / $param->{dpi}, 0, 0) if (defined $param->{dpi});

	$page->DrawImage($this->{image}, 0, 0, $this->{width}, $this->{height});

	$page->GRestore();
}



















#=======================================================================================================================
#
#=======================================================================================================================
package LibPDF;
use strict;
use PDF::Haru;
use Data::Dumper;

sub new {
	my $this = shift;
	my $class = ref($this) || $this;
	my $self = {};
	bless $self, $class;

	$self->start();

	return $self;
}

sub start {
	my ($this) = @_;

	$this->{pdf} = PDF::Haru::New();

	$this->{pdf}->SetCompressionMode(HPDF_COMP_ALL);


}

sub haru {
	my ($this) = @_;
	return $this->{pdf};
}



sub DESTROY {
	my ($this) = @_;

	$this->{pdf}->Free() if ($this->{pdf});
	$this->{pdf} = undef;
}



1
